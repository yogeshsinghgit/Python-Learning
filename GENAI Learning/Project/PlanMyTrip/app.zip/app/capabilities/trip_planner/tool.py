from langchain_core.tools import tool


@tool
async def trip_planner(destination: str, days: int) -> str:
    """Build a day-by-day itinerary for a destination. Currently returns mocked data."""
    return f"{days}-day itinerary for {destination}"
